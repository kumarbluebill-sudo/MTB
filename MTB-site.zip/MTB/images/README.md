Put destination photos here, named exactly:
bali.jpg  dubai.jpg  thailand.jpg  singmy.jpg  maldives.jpg  swiss.jpg  vietnam.jpg  japan.jpg
(Recommended: 1600px wide, under 300 KB each. If a file is missing, the site shows drawn artwork instead.)
