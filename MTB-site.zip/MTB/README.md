# MTB Holidays

Single-page website for international tour packages, with visa and entry guides for Indian passport holders.

- `index.html` – the whole site (edit `WHATSAPP`, `EMAIL`, `BRAND`, `PACKAGES`, `VISA` and `PHOTOS` near the top of the script)
- `images/` – destination photos (see `images/README.md`)

Visa information was checked on 21 September 2026 and must be re-verified against official sources before use.

Host free with GitHub Pages: Settings > Pages > Deploy from branch > `main` / root.
